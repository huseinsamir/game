<?php
require 'db.php';
// Get today's date
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT * FROM lessons WHERE date = ? LIMIT 1");
$stmt->execute([$today]);
$lesson = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تعلمها ببساطة | درس اليوم</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>🎓 تعلمها ببساطة</h1>
    <?php if ($lesson): ?>
      <div class="lesson-card">
        <h2>📌 <?php echo htmlspecialchars($lesson['title']); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($lesson['content'])); ?></p>
        <span class="category">📂 <?php echo htmlspecialchars($lesson['category']); ?></span>
        <p class="date">📅 <?php echo $lesson['date']; ?></p>
      </div>
    <?php else: ?>
      <p>لا يوجد درس لهذا اليوم بعد. ✍️</p>
    <?php endif; ?>
    <a href="all_lessons.php">📚 كل الدروس</a>
  </div>
</body>
</html>
