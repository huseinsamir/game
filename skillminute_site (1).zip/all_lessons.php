<?php
require 'db.php';
$lessons = $pdo->query("SELECT * FROM lessons ORDER BY date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>📚 كل الدروس</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>📚 كل الدروس</h1>
    <?php foreach ($lessons as $lesson): ?>
      <div class="lesson-card">
        <h2>📌 <?php echo htmlspecialchars($lesson['title']); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($lesson['content'])); ?></p>
        <span class="category">📂 <?php echo htmlspecialchars($lesson['category']); ?></span>
        <p class="date">📅 <?php echo $lesson['date']; ?></p>
      </div>
    <?php endforeach; ?>
    <a href="index.php">🔙 عودة لدرس اليوم</a>
  </div>
</body>
</html>
