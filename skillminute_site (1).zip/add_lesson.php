<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = $_POST['title'];
  $content = $_POST['content'];
  $category = $_POST['category'];
  $date = $_POST['date'] ?: date('Y-m-d');
  $stmt = $pdo->prepare("INSERT INTO lessons (title, content, category, date) VALUES (?, ?, ?, ?)");
  $stmt->execute([$title, $content, $category, $date]);
  echo "<p>تمت إضافة الدرس بنجاح 🎉</p><a href='add_lesson.php'>إضافة درس آخر</a> | <a href='index.php'>الرئيسية</a>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>➕ إضافة درس</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>➕ إضافة درس جديد</h1>
    <form method="POST">
      <input type="text" name="title" placeholder="عنوان الدرس" required><br>
      <textarea name="content" placeholder="محتوى الدرس" required></textarea><br>
      <select name="category">
        <option value="تقنية">تقنية</option>
        <option value="تواصل">تواصل</option>
        <option value="نفسية">نفسية</option>
        <option value="إنتاجية">إنتاجية</option>
      </select><br>
      <input type="date" name="date"><br>
      <button type="submit">💾 إضافة الدرس</button>
    </form>
  </div>
</body>
</html>
