<?php
$pdo = new PDO('sqlite:database/lessons.db');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>